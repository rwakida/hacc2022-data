<?php
$GLOBALS['LOG_PATH'] = 'log/production.log';
$GLOBALS['SQLITE_USER'] = 'username';
$GLOBALS['SQLITE_PASS'] = 'password';
$GLOBALS['SQLITE_LOCATION'] = 'results/legtrack.db';
?>
